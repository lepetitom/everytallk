## Cedits

Config based from https://github.com/kadamwhite/wp-block-hmr-demo
